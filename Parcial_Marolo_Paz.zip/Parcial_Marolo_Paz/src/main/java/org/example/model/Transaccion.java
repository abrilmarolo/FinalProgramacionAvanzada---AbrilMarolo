package org.example.model;
import java.sql.Date;

public class Transaccion {
    private int id;
    private float monto;
    private Date fecha;
    private String tipo;

    public Transaccion(float monto, Date fecha,String tipo) {
        this.monto = monto;
        this.fecha = fecha;
        this.tipo = tipo;
    }

    public Transaccion(int id, float monto, Date fecha, String tipo) {
        this.id = id;
        this.fecha = fecha;
        this.monto = monto;
        this.tipo = tipo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public float getMonto() {
        return monto;
    }

    public void setMonto(float monto) {
        this.monto = monto;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}
