package org.example.ui;

import org.example.DAO.CajeroDAOImpl;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ReponerFrame extends JFrame {
    private JTextField depositarField;
    private JTextField idField;
    private JLabel depositarLabel;
    private JLabel cajeroLabel;
    private JButton boton;
    public ReponerFrame() {
        setTitle("Empleado");
        this.setSize(480, 250);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);

        this.setLayout(null);

        JPanel panel = new JPanel();
        panel.setBounds(0, 0, 500, 200);
        panel.setLayout(null);

        depositarLabel = new JLabel("Cantidad a depositar:");
        depositarLabel.setBounds(165, 5, 140, 40);
        depositarField = new JTextField();
        depositarField.setBounds(125, 40, 200, 25);
        cajeroLabel = new JLabel("Seleccionar id del cajero");
        cajeroLabel.setBounds(155, 70, 140, 40);
        idField = new JTextField();
        idField.setBounds(125, 105, 200, 25);

        panel.add(depositarField);
        panel.add(depositarLabel);
        panel.add(cajeroLabel);
        panel.add(idField);

        boton = new JButton("Depositar");
        boton.setBounds(155, 150, 140, 40);
        boton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sendData();
                dispose();
            }
        });

        panel.add(boton);
        add(panel);
        this.setVisible(true);
    }
    private void sendData() {
        CajeroDAOImpl cajero = new CajeroDAOImpl();
        String depositar = depositarField.getText();
        float montodepositar = Float.parseFloat(depositar);
        String id = idField.getText();
        int numeroid = Integer.parseInt(id);
        System.out.println("Monto depositado: " + montodepositar);
        cajero.actualiarCajero(montodepositar, numeroid);

    }
}
