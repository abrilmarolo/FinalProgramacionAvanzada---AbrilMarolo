package org.example.ui;

import org.example.DAO.CajeroDAOImpl;
import org.example.DAO.TransaccionDAOImpl;
import org.example.model.Cajero;
import org.example.model.Transaccion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class VentanaEmpleado extends JFrame {
    private JButton boton1;
    private JButton boton2;

    public VentanaEmpleado() {
        this.setTitle("Empleado");
        this.setSize(480, 180);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        this.setLayout(null);

        JPanel panel = new JPanel();
        panel.setBounds(0, 0, 500, 200);
        panel.setLayout(null);

        this.boton1 = new JButton("Reponer Dinero");
        this.boton1.setBounds(165, 15, 140, 40);
        boton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                reponer();
                dispose();
            }
        });
        panel.add(this.boton1);

        this.boton2 = new JButton("Listado de Transacciones");
        this.boton2.setBounds(125, 75, 220, 40);
        boton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                listarTodasTransferencias();
                dispose();
            }
        });
        panel.add(this.boton2);
        add(panel);
        this.setVisible(true);
    }

    private void listarTodasTransferencias() {
        TransaccionDAOImpl transDAO = new TransaccionDAOImpl();
        List<Transaccion> todasTransacciones = transDAO.recuperarTodasTransacciones();

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                TransaccionesTableFrame tableFrame = new TransaccionesTableFrame(todasTransacciones);
                tableFrame.setVisible(true);
            }
        });
    }

    private void reponer() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                ReponerFrame swingReponer = new ReponerFrame();
                swingReponer.setVisible(true);
            }
        });
    }

   // public static void main(String[] args) {
    //   VentanaEmpleado empleado = new VentanaEmpleado();
    // empleado.setVisible(true);
    // }
}
