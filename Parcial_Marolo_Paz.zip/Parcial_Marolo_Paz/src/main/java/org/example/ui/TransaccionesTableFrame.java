package org.example.ui;

import org.example.model.Transaccion;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class TransaccionesTableFrame extends JFrame{
    public TransaccionesTableFrame( List<Transaccion> transacciones) {
        setTitle("Listado de Transacciones");
        setSize(400, 300);
        this.setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new BorderLayout());

        DefaultTableModel tableModel = new DefaultTableModel();
        tableModel.addColumn("ID");
        tableModel.addColumn("FECHA");
        tableModel.addColumn("MONTO");
        tableModel.addColumn("TIPO");

        for (Transaccion transaccion : transacciones) {
            Object[] row = {transaccion.getId(), transaccion.getFecha(),transaccion.getMonto(), transaccion.getTipo()};
            tableModel.addRow(row);
        }

        JTable table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);

        setContentPane(panel);

        setVisible(true);
    }
}
