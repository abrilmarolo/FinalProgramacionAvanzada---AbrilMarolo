package org.example.ui;

import org.example.DAO.TransaccionDAOImpl;
import org.example.model.Transaccion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Date;
import java.time.Instant;

public class DepositarFrame extends JFrame{
    private JTextField cantidadDepositar;
    private JLabel labelDepositar;


    public DepositarFrame() {
        this.setTitle("Deposito");
        this.setSize(480, 180);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        this.setLayout(null);

        JPanel panel = new JPanel();
        panel.setBounds(0, 0, 500, 180);
        panel.setLayout(null);

        labelDepositar = new JLabel("Cantidad a depositar:");
        labelDepositar.setBounds(165, 10, 140, 40);
        cantidadDepositar = new JTextField();
        cantidadDepositar.setBounds(125, 45, 200, 25);

        panel.add(labelDepositar);
        panel.add(cantidadDepositar);
        JButton boton = new JButton("Depositar");
        boton.setBounds(155, 80, 140, 40);
        boton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sendData();
                dispose();
            }
        });

        panel.add(boton);

        add(panel);
    }

    public void sendData() {
        String deposito = "deposito";
        TransaccionDAOImpl transferencia = new TransaccionDAOImpl();

        String depositar = cantidadDepositar.getText();
        float montoDepositar = Float.parseFloat(depositar);
        System.out.println("Monto depositado: " + montoDepositar);
        Date fecha = new Date(Instant.now().toEpochMilli());
        Transaccion unaTransferencia = new Transaccion(montoDepositar, fecha,deposito);
        transferencia.agregarTransaccion(unaTransferencia);

    }
}
