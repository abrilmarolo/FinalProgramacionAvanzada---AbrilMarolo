package org.example.ui;

import org.example.DAO.TransaccionDAOImpl;
import org.example.model.Transaccion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.time.Instant;

public class RetirarFrame extends JFrame {

    private JTextField retirarField;
    private JLabel retirarLabel;

    public RetirarFrame() {
        this.setTitle("Retiro");
        this.setSize(480, 180);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        this.setLayout(null);

        JPanel panel = new JPanel();
        panel.setBounds(0, 0, 500, 180);
        panel.setLayout(null);

        retirarLabel = new JLabel("Cantidad a retirar:");
        retirarLabel.setBounds(165, 10, 140, 40);
        retirarField = new JTextField();
        retirarField.setBounds(125, 45, 200, 25);

        panel.add(retirarLabel);
        panel.add(retirarField);


        JButton boton = new JButton("Retirar");
        boton.setBounds(155, 80, 140, 40);
        boton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sendData();
                dispose();
            }
        });

        panel.add(boton);

        add(panel);
    }



    private void sendData() {
        TransaccionDAOImpl transaccion = new TransaccionDAOImpl();
        String retirar = retirarField.getText();
        float monto = Float.parseFloat(retirar);
        String transferencia = "transferencia";
        Date fecha = new Date(Instant.now().toEpochMilli());
        System.out.println("Monto retirado: " + monto);
        Transaccion unaTransaccion = new Transaccion(monto, fecha, transferencia);
        transaccion.agregarTransaccion(unaTransaccion);


    }


}
