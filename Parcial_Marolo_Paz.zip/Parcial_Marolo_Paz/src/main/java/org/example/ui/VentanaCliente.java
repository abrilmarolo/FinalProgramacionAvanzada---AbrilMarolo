package org.example.ui;

import org.example.DAO.TransaccionDAO;
import org.example.DAO.TransaccionDAOImpl;
import org.example.model.Transaccion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class VentanaCliente extends JFrame {
    private JButton boton1;
    private JButton boton2;
    private JButton boton3;

    public VentanaCliente() {
        this.setTitle("Cliente");
        this.setSize(480, 230);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        this.setLayout(null);

        JPanel panel = new JPanel();
        panel.setBounds(0, 0, 500, 200);
        panel.setLayout(null);

        this.boton1 = new JButton("Extraer Dinero");
        this.boton1.setBounds(165, 10, 140, 40);
        boton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                extraer();
                dispose();
            }
        });
        panel.add(this.boton1);

        this.boton2 = new JButton("Depositar Dinero");
        this.boton2.setBounds(165, 70, 140, 40);
        boton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                depositar();
                dispose();
            }
        });
        panel.add(this.boton2);

        this.boton3 = new JButton("Listar Transacciones");
        this.boton3.setBounds(125, 130, 220, 40);
        boton3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                listarTransacciones();
                dispose();
            }
        });
        panel.add(this.boton3);

        add(panel);
    }

    private void listarTransacciones() {
        TransaccionDAO transaccionDAO = new TransaccionDAOImpl();
        List<Transaccion> transacciones = transaccionDAO.recuperarTodasTransacciones();
        for (Transaccion transaccion : transacciones) {
            System.out.println(transaccion);
        }

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                TransaccionesTableFrame tableFrame = new TransaccionesTableFrame(transacciones);
                tableFrame.setVisible(true);

            }
        });
    }

    private void depositar() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                DepositarFrame swingDepositar = new DepositarFrame();
                swingDepositar.setVisible(true);
            }
        });
    }

    private void extraer() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                RetirarFrame swingRetirar = new RetirarFrame();
                swingRetirar.setVisible(true);
            }
        });
    }

    //public static void main(String[] args) {
    //VentanaCliente cliente = new VentanaCliente();
    //    cliente.setVisible(true);
    //}
}
