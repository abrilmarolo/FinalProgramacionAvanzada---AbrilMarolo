package org.example;


import org.example.DAO.CajeroDAOImpl;
import org.example.model.Cajero;
import org.example.ui.VentanaCliente;
import org.example.ui.VentanaEmpleado;

public class Main {
    public static void main(String[] args) {
        CajeroDAOImpl cajeroDAO = new CajeroDAOImpl();
        Cajero cajero1 = new Cajero("Santander", "Corrientes 1345", 50000);
        Cajero cajero2 = new Cajero("Frances", "Pasteur 498", 40000);
        cajeroDAO.aniadirCajero(cajero1);
        cajeroDAO.aniadirCajero(cajero2);
        VentanaEmpleado empleado = new VentanaEmpleado();
        empleado.setVisible(true);
        VentanaCliente cliente = new VentanaCliente();
        cliente.setVisible(true);
        //aparecen ambas ventanas al mismo tiempo en el mismo lugar del medio
    }

}