package org.example.DAO;


import org.example.model.Transaccion;

import java.util.List;

public interface TransaccionDAO {
    public void agregarTransaccion(Transaccion transaccion);
    public List<Transaccion> recuperarTodasTransacciones();
}
