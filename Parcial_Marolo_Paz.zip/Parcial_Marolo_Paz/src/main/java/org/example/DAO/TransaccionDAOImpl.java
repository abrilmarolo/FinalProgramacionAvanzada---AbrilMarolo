package org.example.DAO;

import org.example.model.Transaccion;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TransaccionDAOImpl implements TransaccionDAO{
    private static final String URL = "jdbc:h2:./data/test";
    private static final String USER = "sa";
    private static final String PASSWORD = "";
    private static final String TABLE_NAME = "transacciones";

    public TransaccionDAOImpl() {
        try {
            Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
            Statement statement = connection.createStatement();
            String createTableQuery = "CREATE TABLE IF NOT EXISTS " + TABLE_NAME +
                    "(id INT AUTO_INCREMENT PRIMARY KEY, monto float, fecha DATE, tipo VARCHAR(30))";
            statement.executeUpdate(createTableQuery);
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    @Override
    public void agregarTransaccion(Transaccion transaccion) {
        try(Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);){
            String insertQuery = "INSERT INTO " + TABLE_NAME + " (monto, fecha,  tipo) VALUES (?, ?, ?)";
            PreparedStatement pst = connection.prepareStatement(insertQuery, Statement.RETURN_GENERATED_KEYS);
            pst.setFloat(1, transaccion.getMonto());
            pst.setDate(2, new java.sql.Date(transaccion.getFecha().getTime()));
            pst.setString(3, transaccion.getTipo());
            pst.executeUpdate();

            ResultSet generateKeys = pst.getGeneratedKeys();
            if (generateKeys.next()) {
                int id = generateKeys.getInt(1);
                transaccion.setId(id);
            }

            System.out.println("La Transaccion " + transaccion.getId() + " del tipo " + transaccion.getTipo() + " con el monto $" + transaccion.getMonto());
        }catch (SQLException e){
            e.printStackTrace();
        }
    }

    @Override
    public List<Transaccion> recuperarTodasTransacciones() {
        List<Transaccion> transacciones = new ArrayList<>();

        try {
            Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
            Statement statement = connection.createStatement();
            String selectQuery = "SELECT * FROM " + TABLE_NAME;
            ResultSet resultSet = statement.executeQuery(selectQuery);
            while (resultSet.next()) {
                float monto = resultSet.getFloat("monto");
                String tipo = resultSet.getString("tipo");
                Date fecha = resultSet.getDate("fecha");
                int id = resultSet.getInt("id");
                Transaccion transaccion = new Transaccion (id,monto, fecha,tipo);
                transacciones.add(transaccion);
            }
            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.println("Transaccion guardada!");
        return transacciones;

    }

}
