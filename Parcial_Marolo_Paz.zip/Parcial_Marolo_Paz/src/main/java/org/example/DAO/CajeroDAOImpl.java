package org.example.DAO;

import org.example.model.Cajero;
import org.example.model.Transaccion;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CajeroDAOImpl implements CajeroDAO{
    private static final String URL = "jdbc:h2:./data/test";
    private static final String USER = "sa";
    private static final String PASSWORD = "";
    private static final String TABLE_NAME = "cajeros";
    public CajeroDAOImpl() {
        try {
            Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
            Statement statement = connection.createStatement();
            String createTableQuery = "CREATE TABLE IF NOT EXISTS " + TABLE_NAME +
                    "(id INT AUTO_INCREMENT PRIMARY KEY, nombre VARCHAR(300), direccion VARCHAR(300), dinero float)";
            statement.executeUpdate(createTableQuery);
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Cajero aniadirCajero(Cajero cajero) {
        try {
            Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
            String insertQuery = "INSERT INTO " + TABLE_NAME + "(nombre, direccion, dinero) VALUES (?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
            preparedStatement.setString(1, cajero.getNombre());
            preparedStatement.setString(2, cajero.getDireccion());
            preparedStatement.setFloat(3, cajero.getDinero());
            preparedStatement.executeUpdate();

            ResultSet generateKeys = preparedStatement.getGeneratedKeys();
            if (generateKeys.next()) {
                int id = generateKeys.getInt(1);
                cajero.setId(id);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cajero;
    }

    @Override
    public Cajero devolverPorID(int id) {
        Cajero cajero= null;
        try(Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);){
            String insertQuery = "SELECT * FROM " + TABLE_NAME + " WHERE id = ?";
            PreparedStatement pst = connection.prepareStatement(insertQuery);
            pst.setInt(1, id);
            try(ResultSet rs = pst.executeQuery()){
                if (rs.next()){
                    String nombre = rs.getString("nombre");
                    String direccion = rs.getString("direccion");
                    float dinero = rs.getFloat("dinero");

                    cajero = new Cajero (nombre, direccion, dinero);
                }
            }
            System.out.println("El cajero buscado es: " + cajero.getNombre() + " de la direccion " + cajero.getDireccion() + " con el dinero " + cajero.getDinero());
        }catch(SQLException e){
            e.printStackTrace();
        }
        return cajero;
    }

    @Override
    public List<Cajero> recuperarTodosCajero() {
        List<Cajero> cajeros = new ArrayList<>();

        try {
            Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
            Statement statement = connection.createStatement();
            String selectQuery = "SELECT * FROM " + TABLE_NAME;
            ResultSet resultSet = statement.executeQuery(selectQuery);
            while (resultSet.next()) {
                String nombre = resultSet.getString("nombre");
                String direccion = resultSet.getString("direccion");
                float dinero = resultSet.getFloat("dinero");
                Cajero cajero = new Cajero (nombre,direccion,dinero);
                cajeros.add(cajero);
            }
            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.println("Cajero guardado!");
        return cajeros;

    }

    @Override
    public void actualiarCajero(float saldo, int id) {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String selectQuery = "SELECT dinero FROM " + TABLE_NAME + " WHERE id = ?";
            try (PreparedStatement selectPst = connection.prepareStatement(selectQuery)) {
                selectPst.setInt(1, id);
                try (ResultSet resultSet = selectPst.executeQuery()) {
                    while (resultSet.next()) {
                        float dineroActual = resultSet.getFloat("dinero");
                        float dineroNuevo = saldo + dineroActual;

                        String updateQuery = "UPDATE " + TABLE_NAME + " SET dinero = ? WHERE id = ?";
                        try (PreparedStatement updatePst = connection.prepareStatement(updateQuery)) {
                            updatePst.setFloat(1, dineroNuevo);
                            updatePst.setFloat(2, id);
                            int rowsUpdated = updatePst.executeUpdate();

                            if (rowsUpdated > 0) {
                                System.out.println("Se a acutualizado a $" + dineroNuevo + " el cajero " + id);
                            }
                        }
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
}
