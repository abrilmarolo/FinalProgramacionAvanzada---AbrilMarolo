package org.example.DAO;

import org.example.model.Cajero;

import java.util.List;

public interface CajeroDAO {
    public Cajero aniadirCajero(Cajero cajero);
    public Cajero devolverPorID(int id);
    public List<Cajero> recuperarTodosCajero();
    public void actualiarCajero(float saldo, int id);
}
